** READ ME ** 

To run Assignment 1 follow these steps:

1. Unzip the submitted '4867444' folder and locate the directory the 'assignment1.java' file is located.

2. On Windows:

	i) Open Command Prompt and run 'cd ~directory where assignment1.java is located~'
	ii)  Run 'javac assignment1.java'command to compile file.
	iii) Run 'java assignment1' command to run file.
	iv) You should see valid output in command prompt where UCF ID is: 4867444