** READ ME ** 

To run Assignment 2 follow these steps:

1. Unzip the submitted '4867444' folder and locate the directory the 'assignment2.java' file is located.

2. On Windows:

	i) Open Command Prompt and run 'cd ~directory where assignment2.java is located~'
	ii)  Run 'javac assignment2.java'command to compile file.
	iii) Run 'java assignment2' command to run file.
	iv) Enter the vertex you would like the program to start at. (I used last 2 digits of my UCF ID: 44)
	v) You should see valid output in a text file saved in the same directory as where you ran this program titled 'assignment2_output.txt.