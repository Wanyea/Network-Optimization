** READ ME ** 

To run Assignment 3 follow these steps:

1. Unzip the submitted '4867444' folder and locate the directory the 'assignment3.java' file is located.

2. On Windows:

	i) Open Command Prompt and run 'cd ~directory where assignment3.java is located~'
	ii)  Run 'javac assignment3.java'command to compile file.
	iii) Run 'java assignment3' command to run file.
	iv) You should see valid output in a text file saved in the same directory as where you ran this program titled 'assignment3_output.txt.