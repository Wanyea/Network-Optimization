** READ ME ** 

To run Final Project follow these steps:

1. Unzip the submitted 'Final Project' folder and locate the directory the 'RecommendaterSystem.java' file is located.

2. On Windows:

	i) Open Command Prompt and run 'cd ~directory where RecommendaterSystem.java is located~'
	ii)  Run 'javac RecommendaterSystem.java'command to compile file.
	iii) Run 'java RecommendaterSystem.java' command to run file.
	iv) You should see valid output in a text file saved in the same directory as where you ran this program titled 'amazon_predictions_output.txt'.
	v) If you open this file it should show the top 5 items you we're recommended. 